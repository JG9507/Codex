# 《正经胡说报》→ Gemini 交接包（Grok Bot 核实版）

日期：2026-10-30 Asia/Hong_Kong  
用途：Gemini 写全部文字／YAML；Grok 按指令调工具与剪辑。

---

## 0. 角色分工（拍板）

| 角色 | 职责 |
|------|------|
| **Gemini** | 阶段 A 提案、阶段 B `global_packaging.yaml` + `shots.yaml`、屏上字／ticker、笑点与台词；可附「给 Grok 的 Task Prompt」 |
| **Grok Bot** | 读 YAML／执行指令；调 Seedance／Flow／代码渲染／ffmpeg 分层合成；不改笑点与台词（除非用户要求） |
| **用户** | 确认阶段 A；在 Gemini↔Grok 之间传文件或粘贴 |

---

## 1. 下游 Skill 原文与图层逻辑

### 1.1 「演播室分层新闻短片」(id: `skill-1793320089290`)

原文要点：

- 图层从下到上：**L0 静图 → L1 画中画 → L2 人物（高于 L0/L1）→ L3 滚动条最顶**
- 人声只用 Seedance `generate_audio`；禁 TTS
- 可读中文后期真字体；禁 Seedance／Flow 画长中文
- 画幅默认 **16:9**
- 工具：脚本走「洋葱联播脚本分镜」；主播 L2＝Seedance 绿幕／素底；新闻动画 L1＝Flow；数据科普 L1＝代码优先；合成 ffmpeg

### 1.2 「分镜与提示词」(id: `skill-1792547515678`)

偏通用：拆镜、写 visual prompt、选 T2V/I2V/FLF2V/R2V、比例时长参考资产。本栏目**工程字段以「洋葱联播脚本分镜」的 YAML 为准**；本 skill 仅在需要把 `visual_prompt`／`action_prompt` 扩写成可提交 Seedance／Flow 的长 prompt 时由 Grok 加载。

### 1.3 核心问答（Gemini 点名的三点）

#### A. L0 与 L2 抠像关系（目标流水线）

**标准答案（请按此写脚本）：绿幕／素底 L2 → 下游抠像叠在 L0 静图上；L1、L3 再往上叠。**

- `L2_actor.mode: video_audio`：Seedance I2V，首帧为**绿幕或纯色底主播定妆**（非已画好的完整演播室），`generate_audio: true`。
- `L0_bg`：空厅＋空屏框静图（无人或人已抠掉）。
- **不要**再走「EP001 旧法」：把已画满演播室＋乱码字的底图直接 I2V（L0+L2 合一）再靠大蒙版盖字——那是挡人的来源。
- 例外：临时返修旧素材时，可对成片做视频抠像得到 L2 alpha；新集不要依赖此路径。

#### B. L1 画中画尺寸比例

- **成片画幅**：16:9（目标 1920×1080）。
- **演播室构图习惯**：主播偏左约 40–45%，右侧 LED／新闻框约 50–55%（见历史定妆）。
- **给 Flow 的生成画幅**：默认仍出 **16:9**；下游按 `layout` 几何裁进右屏／画中画框（将落盘 `layout.json` 的 `x,y,w,h` 相对坐标）。
- 不要默认 1:1，除非某条 shot 明确要求方形贴图。
- `layout: FULL_L1` 时 L1 铺满 16:9，无小框。

#### C. 音频剥离（`audio_only`）

**支持。** 流程：Seedance 仍生成带声视频 → Grok 用 ffmpeg **只抽音轨**（wav/aac）贴到 FULL_L1 的 B-roll／图表时间轴下，视频轨丢弃或不用。  
YAML 标记：`L2_actor.mode: audio_only` + 仍填 `seedance_line` + 通常 `layout: FULL_L1`。

---

## 2. 三大工具硬参数（Comfy CLI 已核对）

### 2.1 Seedance（L2＋人声）

来源：`comfy generate schema seedance`（2026-10-30）

| 项 | 值 |
|----|-----|
| 模式 | **T2V 或 I2V**（`image` 可选；本栏目 L2 **优先 I2V**＋绿幕首帧） |
| 模型（本栏目） | `seedance-1-5-pro-251215`（`generate_audio` **仅 1.5 Pro**） |
| `duration` | **整数秒 3–12**（schema 为 integer；**不要写 7.5**，应 8） |
| `resolution` | `480p` \| `720p` \| `1080p` |
| `ratio` | 含 `16:9`（成片用）等 |
| `generate_audio` | boolean；与口型匹配的合成音 |
| 音色锁 | **无** reference-audio／voice_id 参数；靠 **prompt 内 `voice_style`／角色描述** 尽量稳住；跨镜复用同一段 voice 描述 + 同一首帧图 |
| 调用例 | `comfy generate seedance --prompt "..." --image <绿幕定妆> --model seedance-1-5-pro-251215 --ratio 16:9 --resolution 1080p --duration 8 --generate_audio true --download clips/...` |

**对台词的含义**：按 4 字/秒 + 单镜 ≤45 字算完后，`dur_sec` **再向上取整到整数秒** 再交给 Seedance。

### 2.2 Flow（L1 动态／部分 L0 动效）

| 项 | 现状 |
|----|------|
| 入口 | 浏览器 Google Flow（Grok 派 computerUse）；非 Comfy 同一 CLI |
| Prompt 语言 | **Gemini 可直接给英文 visual_prompt**（推荐）；也可中英并列。Grok 仅在过短时扩写，不擅自改含义 |
| 试跑常用时长 | **约 6–8s／段**（见 `flow-trial/PLAN.md`／`FLOW_PROMPTS.md`） |
| 若口播 8s、Flow 一段不够 | 拆 2 段 L1 或 loop／定格末帧对齐声轨（Grok 合成时处理）；YAML 可拆成 `body_a_l1a`／`l1b` 两镜或同一镜注 `flow_segments: 2` |

### 2.3 Code 成片（L1 图表／字卡）

| 项 | 现状 |
|----|------|
| 引擎 | **无固定 chart JSON schema**；Grok **按镜现场**写 Python（Pillow／matplotlib）或 HTML+Canvas／ffmpeg 渲染 MP4／PNG |
| Gemini 怎么喂 | 在 `L1_media.visual_prompt` 或 `on_screen.l1_overlay_text` 写清：图表类型、系列名、假数据点、配色、是否动画；可读汉字只进后期字，不进 Flow |
| 已有样例 | `flow-trial/assets/broll/V_CHART_brain_smoothness.jpg`；`ai-fintech-sample/code/body_av.mp4` 等 |

---

## 3. 固定资产清单（当前真实路径）

工程根（历史试片，尚未全部迁到 `video-projects`）：

`/workspace/briefs/ai-fintech-sample/flow-trial/`

新集建议根：`/workspace/video-projects/zhengjing-hushuo/`（可把下方资产拷入 `refs/`）

### 3.1 角色／定妆（女主播）

| 代号 | 路径 |
|------|------|
| `D1_ep001_open_16x9` | `flow-trial/assets/anchor/D1_ep001_open_16x9.jpg` |
| `D2_ep001_close_16x9` | `flow-trial/assets/anchor/D2_ep001_close_16x9.jpg` |
| `D1_ep001_open_ticker_16x9` | `flow-trial/assets/anchor/D1_ep001_open_ticker_16x9.jpg`（含 ticker 烧录，**新流水线慎用**） |
| 脸／姿态参考 | `A1_face.jpg` `B1_seated.jpg` `C1_neutral.jpg` `C2_speaking.jpg` 等同目录 |
| 早期竖屏开／收 | `assets/studio_anchor_open.png` `studio_anchor_close.png` |

**缺口（请 Gemini 知晓）**：

- 尚无独立「纯绿幕主播首帧」资产 ID → 新集需先生成／导出 `refs/anchor_main_greenscreen_ms.png` 等，再写入 `roles.*.visual_ref`。
- **男播音**：无独立出镜定妆；`vo_male` 目前多为 `audio_only`。无锁定音色 ID（Seedance 无该字段）。
- TTS 目录 `flow-trial/tts/*.mp3` 为**旧轨，禁止新集使用**。

### 3.2 L0／包装／转场

| 代号 | 路径 | 时长 |
|------|------|------|
| Logo 飞出 | `flow-trial/trans/logo_out.mp4` | **2.000s** |
| Logo 飞回 | `flow-trial/trans/logo_in.mp4` | **2.000s** |
| Logo 静帧素材 | `flow-trial/assets/logo/logo_metal.jpg` `logo_stamp.jpg` `logo_corner.jpg` | — |
| B-roll 静帧 | `assets/broll/V_CHART_brain_smoothness.jpg` `V_BED_lie_in.jpg` `V_METRO_fake_sleep_award.jpg` | — |

### 3.3 音效／BGM

| 项 | 状态 |
|----|------|
| 片头交响乐／快讯提示音／底噪 | **尚未入库为正式资产**；EP001 主要靠 Seedance 原声。Gemini 可在 `cue_note` 写需求，Grok 用免版权／代码合成垫乐，或标 `TODO_sfx` |

### 3.4 Seedance 已生成片段（参考，非固定资产）

`flow-trial/in/seedance_audio/{open_a,b,c,close_a,b,body_a1,a2,body_b1,b2}.mp4`

---

## 4. 三方交接方式（推荐）

1. **传话**：Gemini 把两份 YAML **写入**（或用户保存到）  
   ` /workspace/video-projects/zhengjing-hushuo/scripts/<EP>_global_packaging.yaml`  
   ` /workspace/video-projects/zhengjing-hushuo/scripts/<EP>_shots.yaml`  
   聊天里可再贴摘要；**以文件为准**。
2. **指令粒度（最省事）**：**YAML 纯数据 + 文末一段给 Grok 的自然语言 Task Prompt**（例：「读取上述两文件；先为 `video_audio` 镜跑 Seedance 1.5 Pro generate_audio；`audio_only` 只抽声；L1 tool=flow 的派 Flow；code 的渲染图表；最后按 shots 顺序 L0→L1→L2→L3 合成」）。用户一键转给 Grok。
3. **阶段纪律**：阶段 A 必须经用户确认后，Gemini 才出阶段 B。

---

## 5. 给 Gemini 的字段提醒（与最新 shots schema 对齐）

```yaml
# 每镜关键字段
id, dur_sec, layout, role_id, char_count, seedance_line
L0_bg
L1_media: { tool: flow|code|still|none, visual_prompt }
L2_actor: { mode: video_audio|audio_only|none, shot_size: MS|MCU|CU, action_prompt }
on_screen: { lower_third, l1_overlay_text }
cue_note, laugh_point
```

铁律摘要：≤45 字／镜；`dur_sec=ceil(字数/4)+0.5` 后再 **整数化** 给 Seedance；同人拆镜改 `shot_size` 或 `layout`；禁真实官媒名；禁 TTS。
