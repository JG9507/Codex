---
name: 洋葱联播脚本分镜
description: >-
  当用户要写洋葱新闻／联播腔搞笑新闻／虚构时事或人物采访类短视频脚本与分镜时使用：输出可直接接「演播室分层新闻短片」的逐镜工程配置（Seedance
  台词、L0–L3、Flow／代码来源）。严禁规划 TTS。
---
# 洋葱联播脚本分镜 (Onion-Style News Script & Storyboard)

为「正经胡说报」等虚构讽刺新闻栏目生成**工程可执行**的脚本与逐镜配置。产出物直接作为下游「演播室分层新闻短片」的合成输入。
**核心边界**：本技能只负责剧本、分镜、图层路由与屏幕字配置；**不**直接调用云端生图/生视频 API，**严禁**规划传统 TTS（所有人声均由下游 Seedance 节点生成）。

---

## 1. 适用场景与禁区

- **适用**：洋葱风虚构联播（`bulletin`）、一本正经假采访（`interview`）、虚构人物传记胡说（`profile`）、混合型栏目（`hybrid`）。
- **禁用**：真实新闻早报、严肃历史人物纪实、商业产品宣传片。

---

## 2. 铁律与硬约束（违反任意一条视为生成失败）

1. **算术与时长铁律（防截断/防鬼畜）**：
   - 联播腔标准语速为 **4 字/秒**（含标点停顿）。
   - 单镜 `dur_sec` 硬上限为 **12 秒**（建议控制在 5–10 秒）。
   - **单镜 `seedance_line` 字数硬上限为 45 个汉字（含标点）**。计算公式：`dur_sec = ceil(字数 / 4.0) + 0.5秒呼吸留白`。超长句子必须拆分为多镜！
   - 必须如实填写 `char_count`（与 `seedance_line` 汉字数一致，含标点），严禁 `char_count > 45`。
2. **防跳剪铁律（同人连续拆镜规则）**：
   - 当同一 `role_id` 因台词超长需连续拆分为两镜（如 `open_01` → `open_02`）时，**严禁两镜使用完全相同的 `L2_actor.shot_size` 与 `layout` 硬切**。
   - 必须采用以下任一遮罩手段：① 切换景别（如 `MS` → `MCU`／`CU`）；② 第二镜切换 `layout` 为全屏 L1 类布局（如 `FULL_L1`），并将 `L2_actor.mode` 改为 `audio_only`（主播画外音）。
3. **人声与音轨路由**：
   - 严禁规划 TTS。所有有声镜头的语音均通过下游 Seedance 的 `generate_audio` 产出。
   - `role_id` 对应 `global_packaging.roles`；无声镜头填 `silent`，且 `L2_actor.mode: none`、`seedance_line: ""`、`char_count: 0`。
   - 纯画外音：画面全屏 L1，`L2_actor.mode: audio_only`，仍填 `seedance_line`（下游用对应角色音色锚点生成音频并剥离视频轨）。
   - `seedance_line` 仅限纯中文可读文本，数字需转为中文读法（如 `99.8%` → `百分之九十九点八`），避免多音字歧义，严禁夹杂舞台提示词（如 `（严肃地）`）。
4. **图层职责与文字隔离（防 AI 乱码）**：
   - **L0（`L0_bg`）**：演播室静态背景／外景空镜底板描述或资产名（still）。
   - **L1（`L1_media`）**：`tool` 为 `flow`｜`code`｜`still`｜`none`；`visual_prompt` 只描述画面运动与构图。**严禁**要求 Flow／Seedance 在画面中生成长串中文；可读字写入 `on_screen`。
   - **L2（`L2_actor`）**：`mode` 为 `video_audio`｜`audio_only`｜`none`；出镜动作用 `action_prompt`；景别 `MS`｜`MCU`｜`CU`。
   - **L3／包装**：角标、下三分、Ticker、右屏标题等写入 `on_screen` 与 `global_l3`，下游真字体渲染。
5. **虚构透明**：
   - 严禁伪造真实媒体／机构名作信源；须用一眼可辨的戏仿机构名。
   - 片尾或下三分必须含免责声明。

---

## 3. 洋葱喜剧机制与防尬指南

### 核心反差公式

> **好笑 = 100% 国家级晚间新闻的庄重形式 × 0% 营养价值的世俗荒诞内核**

### 正反例

- ❌ 「专家指出，人类每天吃三百斤石头就能长生不老……」（脱离痛点的纯胡闹）
- ✅ 「世界睡眠组织……赖床被列为一级本能防御……强行早起属于自残。」（庄重推导社畜痛点）
- ❌ 「据统计，10000% 的人喜欢放假。」
- ✅ 「据本台花了三秒钟捏造的数据……百分之九十八点四……大脑皮层光滑度提升三个百分点。」

### 6 大开场钩子（阶段 A 必选其一）

| 代码 | 机制 | 示范 |
|------|------|------|
| `H1` | 严正声明/致歉 | 「首先播报一则严正声明：如果您在本期节目中不幸学到了任何有用知识，纯属本台工作失误。」 |
| `H2` | 假数据三连排 | 三个专业无意义数字 → 摆烂结论 |
| `H3` | 权威匿名信源 | 「据多位不愿透露姓名的本台编导刚刚在厕所拍脑袋证实……」 |
| `H4` | 荒诞现场先行 | 灾难腔描述日常崩溃 → 揭主题 |
| `H5` | 人物命运判词 | 「他曾连续三年在地铁上精准装睡……」 |
| `H6` | 官方共情设问 | 「您是否也曾因为月底余额稳定在零元附近……」 |

---

## 4. 两阶段工作流

### 阶段 A：单页提案（输出后必须暂停，等待用户确认）

Markdown 表格输出；**严禁**在阶段 A 输出逐镜表或长 Prompt：

| 字段 | 规范 |
|------|------|
| 期号与标题 | 严肃联播腔标题 |
| 节目形态 | `bulletin`｜`interview`｜`profile`｜`hybrid` |
| 目标时长与画幅 | 默认 16:9；总秒数与镜数预估 |
| 核心钩子 | `H1`–`H6` + 开场第一句草稿 |
| 核心笑点清单 | 2–3 条（戏仿机构、假数据、荒诞结论） |
| 角色与声音卡 | `role_id`、身份、音色/形象、出镜方式 |
| 段落结构图 | 如开场(2)→Logo→快讯A(2)→快讯B(2)→收束(1) |

> ⏸️ 收尾固定句：「请确认以上提案方向与笑点；如需调整请指出，确认后我将生成阶段 B 逐镜工程配置。」然后**停止生成**。

---

### 阶段 B：逐镜工程配置（用户确认后）

输出并可落盘两份 YAML：

- `scripts/<episode_id>_global_packaging.yaml`
- `scripts/<episode_id>_shots.yaml`

默认目录：`/workspace/video-projects/<project>/scripts/`。

#### 交付物 1：`global_packaging.yaml`

```yaml
project_meta:
  channel_name: "正经胡说报"
  episode_id: "EP001"
  aspect_ratio: "16:9"
  total_duration_sec: 60

roles:
  anchor_main:
    name: "正经女主播"
    visual_ref: "anchor_female_suit_v1"
    voice_style: "标准新闻联播女声，字正腔圆，沉稳零笑场"
  vo_male:
    name: "快讯男播音"
    visual_ref: "anchor_male_audio_ref"
    voice_style: "浑厚央视纪录片男声，严肃紧迫"
  guest_01:
    name: "张先生（受访者）"
    visual_ref: "guest_sleepy_commuter"
    voice_style: "疲惫但一本正经的中年男声"

global_l3:
  logo_text: "正经胡说报"
  opening_right_screen:
    main_title: "正经胡说报"
    sub_title: "创刊特辑：关于本台“零真相”的严正声明"
  closing_right_screen:
    main_title: "正经胡说报"
    disclaimer: "本节目一切人物、数据及标点符号纯属虚构。如有雷同，说明世界疯了。"
  end_card_text: "关注《正经胡说报》，每天精准浪费您宝贵的 60 秒。"
  ticker_items:
    - "【本台快讯】研究发现：人类只要保持呼吸就能有效阻止窒息"
    - "【气象提醒】今日全国大部分地区白天有光，夜间普遍偏黑"
    - "【财经观察】专家指出：钱花光之后账户普遍会出现余额不足现象"
```

#### 交付物 2：`shots.yaml`（字段以此为准）

```yaml
shots:
  - id: "open_01"
    dur_sec: 9.0
    layout: "STUDIO_OTS"
    role_id: "anchor_main"   # 对应 global_packaging.roles；无声填 silent
    char_count: 34           # 必须如实统计 seedance_line 汉字数，严禁 > 45
    seedance_line: "观众朋友们晚上好，欢迎收看正经胡说报。首先向大家致以最诚挚的警告："
    L0_bg: "演播室深蓝主背景_中景底板"
    L1_media:
      tool: "code"           # flow | code | still | none
      visual_prompt: "深蓝色新闻右屏框底板，带有轻微呼吸灯效的地球网格背景，无文字"
    L2_actor:
      mode: "video_audio"    # video_audio | audio_only | none
      shot_size: "MS"        # MS | MCU | CU
      action_prompt: "新闻女主播身穿深色西装正襟危坐，面色凝重，双手交叠在桌面，直视镜头播报，零笑场"
    on_screen:
      lower_third: "本台严正声明：绝不掺杂半点真相"
      l1_overlay_text: "公信力清零计划 · 虚构率 100%"  # 后期真字体叠在 L1 上
    cue_note: "开场第1秒压低片头交响乐"
    laugh_point: "用最严肃的警告句式宣布自己是假新闻"

  - id: "open_02"
    dur_sec: 7.5
    layout: "FULL_L1"        # 同人拆镜：改 layout 或改 shot_size
    role_id: "anchor_main"
    char_count: 28
    seedance_line: "如果您在本期节目中不幸学到了任何有用知识，纯属本台工作失误。"
    L0_bg: "演播室深蓝主背景_中景底板"
    L1_media:
      tool: "flow"
      visual_prompt: "全屏缓慢推镜的演播室灯光虚化空镜，无文字无人脸"
    L2_actor:
      mode: "audio_only"
      shot_size: "MS"
      action_prompt: ""
    on_screen:
      lower_third: "本台严正声明：绝不掺杂半点真相"
      l1_overlay_text: ""
    cue_note: "切全屏 B-roll，保留主播声"
    laugh_point: "致歉声明式免责"
```

**常用 `layout` 枚举（可扩展，须在 notes／提案里自洽）**：`STUDIO_OTS`｜`STUDIO_FRONT`｜`PIP_RIGHT`｜`PIP_LEFT`｜`FULL_L1`｜`FULL_L2`｜`SPLIT_GUEST`

**逐镜必检**：

- [ ] `char_count` = 实际字数且 ≤ 45；`dur_sec = ceil(字数/4)+0.5` 且 ≤ 12
- [ ] 同 `role_id` 相邻出镜：`shot_size` 或 `layout` 至少变一处
- [ ] `audio_only` ⇒ 多为 `FULL_L1`，且仍有 `seedance_line`
- [ ] `L1_media.visual_prompt` 无「生成中文标题／长句」；可读字在 `on_screen`／`global_l3`
- [ ] 戏仿机构名；免责在收束或 ticker／片尾
- [ ] 无 TTS 字段

---

## 5. 形态速查

| 形态 | 要点 |
|------|------|
| `bulletin` | 钩子→Logo→快讯（男声可 `vo_male` + Flow/code）→收束免责 |
| `interview` | 导语→嘉宾问答（可 `SPLIT_GUEST`）→金句→收束 |
| `profile` | 钩子→背景→崛起→转折→金句（标虚构）；口播拆多镜 |
| `hybrid` | 提案写清块序；仍守字数／防跳剪 |

---

## 6. 与其它 skills

| Skill | 关系 |
|-------|------|
| 演播室分层新闻短片 | 下游执行本 YAML |
| 视频脚本 | 通用宽表；本栏目走本技能 |
| 分镜与提示词 | 需更细 visual prompt 时再加载 |
| Comfy Cloud 生成 | 仅生成阶段 |
| Story Studio | 可借人物钩子；禁止借 TTS |

---

## 7. 完成标准

- [ ] 阶段 A 已输出并暂停等待确认
- [ ] 阶段 B 两份 YAML 字段与上方 schema 一致并通过必检
- [ ] 人声仅 Seedance；文字与 AI 画面隔离
- [ ] 笑点为「庄重形式 × 世俗痛点」
