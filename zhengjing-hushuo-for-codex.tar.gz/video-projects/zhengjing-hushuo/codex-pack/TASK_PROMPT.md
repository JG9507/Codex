# Codex 任务：《正经胡说报》从 Step 0 起

## 角色
你在本机（Grok Bot 电脑）已登录的 ChatGPT Codex 会话里工作。模型请用 **GPT-6.1 Terra**（省用量）。

## 已附文档（与当初 Step 0 / Gemini 交接相同）
1. `PROTOCOL_V2.md` — 生产锁定协议（必遵）
2. `GEMINI_HANDOFF.md` — 角色分工、工具参数、资产清单
3. `SKILL_洋葱联播脚本分镜.md`
4. `SKILL_演播室分层新闻短片.md`
5. `SKILL_分镜与提示词.md`

工程根：`/workspace/video-projects/zhengjing-hushuo/`  
Step 0 资产：`refs/anchor_main_greenscreen_ms.png`、`refs/vo_male_anchor_ref.png`、`assets/bg/studio_empty_16x9.png`、`assets/trans/logo_out.mp4`、`assets/trans/logo_in.mp4` 等（见 PROTOCOL 资产表）。

## 工作方式（必须分两阶段）
### 阶段 1 — 先只思考，不要开跑生成
阅读全部文档后，回答：
1. 当前协议／技能／资产是否有明显缺口或矛盾？
2. 若需要优化：列出具体优化项、理由、建议改动（协议段落／YAML 字段／流水线步骤）。
3. 若不需要：明确写「无需优化」并说明理由。
4. 给出「按优化结果（或原文）执行」的分步执行计划。

等人类确认前，**不要**调用 Seedance／Flow／大批量渲染。先把阶段 1 结论写清楚。

### 阶段 2 — 人类确认优化结论后
按确认后的方案从 Step 0 往下执行（脚本/YAML → 生成 → 分层合成）。若本会话无法直接调本机 Comfy／浏览器 Flow，把需要 Grok 代跑的命令与文件路径写成可执行清单。

## 频道调性提醒
《正经胡说报》：100% 纯人工造谣的严肃虚构新闻；联播腔；横屏 16:9；人声只用 Seedance，禁 TTS。
