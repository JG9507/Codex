#!/usr/bin/env python3
"""Render code-based L1 media clips for EP001 at 1920x1080."""
import math, json, subprocess, tempfile, shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path("/workspace/video-projects/zhengjing-hushuo")
L1 = ROOT / "clips" / "l1"
L1.mkdir(parents=True, exist_ok=True)
FONT_R = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
FONT_B = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FPS = 24
W, H = 1920, 1080

def font(size, bold=False):
    path = FONT_B if bold else FONT_R
    try:
        return ImageFont.truetype(path, size, index=0)  # SC
    except Exception:
        return ImageFont.load_default()

def save_mp4(frames_dir, out_mp4, fps=FPS):
    out_mp4 = Path(out_mp4)
    cmd = [
        "ffmpeg", "-y", "-framerate", str(fps),
        "-i", str(frames_dir / "f_%05d.png"),
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        "-movflags", "+faststart", str(out_mp4),
    ]
    subprocess.run(cmd, check=True, capture_output=True)

def n_frames(dur):
    return max(1, int(round(dur * FPS)))

def render_globe(dur, out):
    """dark_blue_broadcast_globe animated card"""
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_globe_"))
    for i in range(nf):
        t = i / FPS
        img = Image.new("RGB", (W, H), (8, 18, 42))
        d = ImageDraw.Draw(img)
        # grid
        for gx in range(0, W, 80):
            d.line([(gx, 0), (gx, H)], fill=(20, 45, 90), width=1)
        for gy in range(0, H, 80):
            d.line([(0, gy), (W, gy)], fill=(20, 45, 90), width=1)
        # rotating globe-ish circles
        cx, cy = W // 2, H // 2
        for r in (180, 260, 340):
            ang = t * 0.4 + r * 0.01
            d.ellipse([cx-r, cy-r, cx+r, cy+r], outline=(40, 120, 220), width=2)
            for k in range(8):
                a = ang + k * math.pi / 4
                x1 = cx + int(r * math.cos(a))
                y1 = cy + int(r * 0.35 * math.sin(a))
                d.ellipse([x1-3, y1-3, x1+3, y1+3], fill=(80, 180, 255))
        # scanline
        sy = int((t * 120) % H)
        d.rectangle([0, sy, W, sy+3], fill=(60, 160, 255, ))
        # vignette-ish border
        d.rectangle([20, 20, W-20, H-20], outline=(30, 90, 180), width=4)
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_warning(dur, out):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_warn_"))
    for i in range(nf):
        t = i / FPS
        img = Image.new("RGB", (W, H), (18, 10, 28))
        d = ImageDraw.Draw(img)
        # diagonal stripes
        for s in range(-H, W+H, 60):
            pts = [(s, 0), (s+30, 0), (s+30+H, H), (s+H, H)]
            d.polygon(pts, fill=(90, 15, 30) if (s//60)%2==0 else (15, 25, 70))
        # triangle
        blink = 0.5 + 0.5 * math.sin(t * 4)
        cx, cy = W//2, H//2 - 40
        tri = [(cx, cy-160), (cx+180, cy+140), (cx-180, cy+140)]
        col = (int(255*blink), int(200*blink), 40)
        d.polygon(tri, outline=col, fill=(40, 20, 10))
        d.polygon(tri, outline=col, width=8)
        # exclamation
        d.rectangle([cx-12, cy-80, cx+12, cy+40], fill=col)
        d.ellipse([cx-14, cy+60, cx+14, cy+88], fill=col)
        d.rectangle([40, 40, W-40, H-40], outline=(200, 60, 60), width=6)
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_dual_gauge(dur, out):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_gauge_"))
    f100, f0 = font(36, True), font(28, False)
    for i in range(nf):
        t = i / max(1, dur - 0.5)
        t = min(1.0, t)
        img = Image.new("RGB", (W, H), (6, 14, 32))
        d = ImageDraw.Draw(img)
        for gx in range(0, W, 60):
            d.line([(gx,0),(gx,H)], fill=(15,30,60))
        # left gauge -> 100%
        lx, ly, R = 520, 540, 220
        d.ellipse([lx-R, ly-R, lx+R, ly+R], outline=(40,80,140), width=18)
        # arc progress (approx with pieslice)
        extent = int(360 * t)
        d.pieslice([lx-R, ly-R, lx+R, ly+R], start=-90, end=-90+extent, fill=(0, 180, 255))
        d.ellipse([lx-R+30, ly-R+30, lx+R-30, ly+R-30], fill=(6,14,32))
        val = int(100 * t)
        d.text((lx-40, ly-30), f"{val}%", font=f100, fill=(120, 220, 255))
        d.text((lx-80, ly+80), "虛構率", font=f0, fill=(180, 200, 230))
        # right gauge stays 0
        rx = 1400
        d.ellipse([rx-R, ly-R, rx+R, ly+R], outline=(40,80,140), width=18)
        d.ellipse([rx-R+30, ly-R+30, rx+R-30, ly+R-30], fill=(6,14,32))
        d.text((rx-30, ly-30), "0%", font=f100, fill=(255, 100, 100))
        d.text((rx-80, ly+80), "公信力", font=f0, fill=(180, 200, 230))
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_line_chart(dur, out):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_chart_"))
    xs_lab = ["收看前", "收看10秒", "收看30秒", "收看60秒"]
    ys = [10, 45, 88, 160]
    f_lab = font(28, False)
    f_title = font(40, True)
    for i in range(nf):
        t = min(1.0, (i / FPS) / max(0.5, dur * 0.85))
        img = Image.new("RGB", (W, H), (10, 16, 28))
        d = ImageDraw.Draw(img)
        # axes area
        left, top, right, bottom = 180, 160, 1740, 900
        d.rectangle([left, top, right, bottom], outline=(60, 90, 140), width=2)
        d.text((left, 60), "《觀眾大腦皮層光滑度走勢圖》", font=f_title, fill=(220, 230, 255))
        # grid
        for g in range(5):
            yy = top + (bottom-top)*g/4
            d.line([(left, yy), (right, yy)], fill=(30, 50, 80))
        # progressive polyline
        pts = []
        n_pts = len(ys)
        progress = t * (n_pts - 1)
        for j in range(n_pts):
            x = left + (right-left) * j / (n_pts-1)
            # map y: 0..180 -> bottom..top (breakout above)
            yv = ys[j]
            y = bottom - (yv / 180.0) * (bottom - top)
            pts.append((x, y))
            d.text((x-40, bottom+20), xs_lab[j], font=f_lab, fill=(160,180,210))
        # draw partial
        draw_n = max(1, int(progress) + 1)
        frac = progress - int(progress)
        draw_pts = pts[:draw_n]
        if draw_n < n_pts:
            x0,y0 = pts[draw_n-1]
            x1,y1 = pts[draw_n]
            draw_pts = pts[:draw_n] + [(x0+(x1-x0)*frac, y0+(y1-y0)*frac)]
        if len(draw_pts) >= 2:
            d.line(draw_pts, fill=(255, 59, 48), width=6)
        for p in draw_pts:
            d.ellipse([p[0]-8, p[1]-8, p[0]+8, p[1]+8], fill=(255, 120, 80))
        # breakout flash near end
        if t > 0.85:
            d.text((right-280, top+20), "衝破！", font=f_title, fill=(255, 80, 60))
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_bulletin(dur, out):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_bull_"))
    f_big = font(48, True)
    f_mid = font(32, False)
    for i in range(nf):
        t = i / FPS
        img = Image.new("RGB", (W, H), (8, 20, 48))
        d = ImageDraw.Draw(img)
        # card slide in
        slide = min(1.0, t / 0.6)
        cx = int(-400 + (W//2 + 400) * slide)
        card = [cx-500, 200, cx+500, 880]
        d.rounded_rectangle(card, radius=20, fill=(16, 36, 72), outline=(200, 40, 40), width=6)
        # stamp
        d.ellipse([cx+280, 240, cx+460, 420], outline=(220, 40, 40), width=8)
        d.text((cx+300, 300), "FAKE", font=f_mid, fill=(220, 50, 50))
        d.text((cx-420, 280), "BREAKING_FAKE_NEWS_01", font=f_mid, fill=(255, 200, 80))
        d.text((cx-420, 420), "世界賴床研究總署", font=f_big, fill=(230, 240, 255))
        d.text((cx-420, 520), "正式公文 · 虛構印章", font=f_mid, fill=(160, 190, 230))
        # alarm icon
        ax, ay = cx-350, 680
        d.ellipse([ax, ay, ax+80, ay+80], outline=(255, 200, 60), width=5)
        d.line([(ax+40, ay+20), (ax+40, ay+50)], fill=(255,200,60), width=4)
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_closing(dur, out):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_close_"))
    for i in range(nf):
        t = i / FPS
        img = Image.new("RGB", (W, H), (8, 16, 36))
        d = ImageDraw.Draw(img)
        glow = int(40 + 30 * math.sin(t * 2))
        d.rectangle([60, 60, W-60, H-60], outline=(180, 150, 60), width=4)
        d.rectangle([80, 80, W-80, H-80], outline=(40, 80, glow+80), width=2)
        # watermark-ish logo mark
        d.ellipse([W//2-120, H//2-120, W//2+120, H//2+120], outline=(60, 100, 160), width=3)
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_award(dur, out, base):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_award_"))
    base_img = Image.open(base).convert("RGB").resize((W, H), Image.LANCZOS)
    for i in range(nf):
        t = i / FPS
        img = base_img.copy()
        # dark vignette
        overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        # golden spotlight
        pulse = 0.5 + 0.5 * math.sin(t * 3)
        for r in range(400, 50, -20):
            a = int(30 * pulse * (1 - r/400))
            od.ellipse([W//2-r, H//2-r-40, W//2+r, H//2+r-40], fill=(255, 200, 60, a))
        # confetti
        import random
        rng = random.Random(42)
        for k in range(40):
            x = rng.randint(0, W)
            y = int((rng.random() * H + t * 200 + k * 17) % H)
            od.rectangle([x, y, x+6, y+12], fill=(255, 215, 80, 200))
        # medal
        mx, my = W//2, 180
        od.ellipse([mx-70, my-70, mx+70, my+70], fill=(255, 200, 40, 230), outline=(255, 240, 160, 255))
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def render_end_card(dur, out, text):
    nf = n_frames(dur)
    td = Path(tempfile.mkdtemp(prefix="l1_end_"))
    f = font(42, True)
    for i in range(nf):
        t = i / max(0.01, dur)
        img = Image.new("RGB", (W, H), (0, 0, 0))
        d = ImageDraw.Draw(img)
        # CRT shrink
        scale = max(0.02, 1.0 - t * 0.95)
        if t < 0.7:
            # measure text
            bbox = d.textbbox((0, 0), text, font=f)
            tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
            d.text(((W-tw)//2, (H-th)//2), text, font=f, fill=(240, 240, 240))
        else:
            # white dot shrink
            r = int(40 * (1 - (t-0.7)/0.3))
            d.ellipse([W//2-r, H//2-r, W//2+r, H//2+r], fill=(255, 255, 255))
        img.save(td / f"f_{i:05d}.png")
    save_mp4(td, out)
    shutil.rmtree(td, ignore_errors=True)

def zoompan_still(src, dur, out):
    """broll placeholder with slow zoom"""
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", str(src),
        "-vf", f"scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,zoompan=z='min(1.15,1+0.0015*on)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={int(dur*FPS)}:s=1920x1080:fps={FPS}",
        "-t", str(dur), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        str(out),
    ]
    subprocess.run(cmd, check=True, capture_output=True)

if __name__ == "__main__":
    # durations placeholder — will be overwritten by trimmed lengths later; use YAML for now
    durs = {
        "open_01": 12, "open_02": 12, "body_a1": 10, "body_a2": 12,
        "body_b1": 12, "body_b2": 7, "body_c1": 7, "body_c2": 7,
        "close_01": 11, "end_card": 2,
    }
    print("Rendering L1 code shots...", flush=True)
    render_globe(durs["open_01"], L1/"open_01.mp4"); print("open_01", flush=True)
    render_warning(durs["open_02"], L1/"open_02.mp4"); print("open_02", flush=True)
    render_dual_gauge(durs["body_a1"], L1/"body_a1.mp4"); print("body_a1", flush=True)
    render_line_chart(durs["body_a2"], L1/"body_a2.mp4"); print("body_a2", flush=True)
    render_bulletin(durs["body_b1"], L1/"body_b1.mp4"); print("body_b1", flush=True)
    base_bed = "/workspace/briefs/ai-fintech-sample/flow-trial/assets/broll/V_BED_lie_in.jpg"
    base_metro = "/workspace/briefs/ai-fintech-sample/flow-trial/assets/broll/V_METRO_fake_sleep_award.jpg"
    # flow placeholders
    if not (L1/"body_b2.mp4").exists() or (L1/"body_b2.mp4").stat().st_size < 10000:
        zoompan_still(base_bed, durs["body_b2"], L1/"body_b2.mp4")
        print("body_b2 PLACEHOLDER", flush=True)
    if not (L1/"body_c1.mp4").exists() or (L1/"body_c1.mp4").stat().st_size < 10000:
        zoompan_still(base_metro, durs["body_c1"], L1/"body_c1.mp4")
        print("body_c1 PLACEHOLDER", flush=True)
    render_award(durs["body_c2"], L1/"body_c2.mp4", base_metro); print("body_c2", flush=True)
    render_closing(durs["close_01"], L1/"close_01.mp4"); print("close_01", flush=True)
    text = "關注《正經胡說報》，每天精準浪費您寶貴的 60 秒。"
    render_end_card(durs["end_card"], L1/"end_card.mp4", text); print("end_card", flush=True)
    print("L1 DONE", flush=True)
