#!/usr/bin/env python3
"""Detect voice end + keep 0.25s breath; write trimmed mp4 + wav + durations.json"""
import json, subprocess, re
from pathlib import Path

ROOT = Path("/workspace/video-projects/zhengjing-hushuo")
SRC = ROOT / "clips" / "seedance"
TRIM = ROOT / "clips" / "trimmed"
AUD = ROOT / "clips" / "audio"
TRIM.mkdir(parents=True, exist_ok=True)
AUD.mkdir(parents=True, exist_ok=True)

SHOTS = ["open_01","open_02","body_a1","body_a2","body_b1","body_b2","body_c1","body_c2","close_01"]
BREATH = 0.25

def probe_dur(path):
    r = subprocess.run([
        "ffprobe","-v","error","-show_entries","format=duration",
        "-of","default=noprint_wrappers=1:nokey=1", str(path)
    ], capture_output=True, text=True)
    return float(r.stdout.strip())

def find_voice_end(mp4):
    """Use silencedetect; take start of last silence that lasts >=0.3s near end, else full-0.1."""
    r = subprocess.run([
        "ffmpeg","-i",str(mp4),"-af","silencedetect=noise=-35dB:d=0.30","-f","null","-"
    ], capture_output=True, text=True)
    log = r.stderr
    starts = [float(x) for x in re.findall(r"silence_start:\s*([0-9.]+)", log)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*([0-9.]+)", log)]
    full = probe_dur(mp4)
    if starts:
        # last silence_start that is after 40% of clip is voice end
        candidates = [s for s in starts if s > full * 0.35]
        if candidates:
            return candidates[-1]
        return starts[-1]
    # fallback: look for silence_end pairs — if none, use 90%
    return full * 0.90

def trim(mp4, out_mp4, end_t):
    subprocess.run([
        "ffmpeg","-y","-i",str(mp4),"-t",f"{end_t:.3f}",
        "-c:v","libx264","-pix_fmt","yuv420p","-crf","18",
        "-c:a","aac","-b:a","192k", str(out_mp4)
    ], check=True, capture_output=True)

def extract_wav(mp4, wav):
    subprocess.run([
        "ffmpeg","-y","-i",str(mp4),"-vn","-ac","1","-ar","16000","-c:a","pcm_s16le",str(wav)
    ], check=True, capture_output=True)

def main():
    durs = {}
    for sid in SHOTS:
        src = SRC / f"{sid}.mp4"
        if not src.exists():
            print("MISSING", sid); continue
        full = probe_dur(src)
        vend = find_voice_end(src)
        end = min(full, vend + BREATH)
        end = max(2.0, min(end, full))
        out = TRIM / f"{sid}.mp4"
        trim(src, out, end)
        actual = probe_dur(out)
        durs[sid] = round(actual, 3)
        extract_wav(out, AUD / f"{sid}.wav")
        print(f"{sid}: full={full:.3f} voice_end={vend:.3f} trim_to={end:.3f} actual={actual:.3f}", flush=True)
    # fixed
    durs["bumper_in"] = 2.0
    durs["bumper_out"] = 2.0
    durs["end_card"] = 2.0
    (ROOT/"clips"/"durations.json").write_text(json.dumps(durs, indent=2, ensure_ascii=False))
    print("DURATIONS", json.dumps(durs, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
