#!/usr/bin/env python3
"""Layer compose EP001 per PROTOCOL_V2. Seedance lost greenscreen → soft elliptical matte for STUDIO_OTS."""
import json, subprocess, tempfile, shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path("/workspace/video-projects/zhengjing-hushuo")
OUT = ROOT / "out"; OUT.mkdir(parents=True, exist_ok=True)
COMP = ROOT / "clips" / "compose"; COMP.mkdir(parents=True, exist_ok=True)
L1 = ROOT / "clips" / "l1"
TRIM = ROOT / "clips" / "trimmed"
AUD = ROOT / "clips" / "audio"
BG = ROOT / "assets" / "bg" / "studio_empty_16x9.png"
LAYOUT_PATH = ROOT / "assets" / "layout.json"
FONT_B = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FONT_R = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
W, H, FPS = 1920, 1080, 24

SCREEN = {"x": 0.48, "y": 0.18, "w": 0.48, "h": 0.54}
ACTOR = {"x": 0.00, "y": 0.02, "w": 0.58, "h": 0.96}
LAYOUT_PATH.write_text(json.dumps({
    "canvas": {"w": W, "h": H},
    "studio_ots_screen": SCREEN,
    "studio_ots_actor": ACTOR,
    "mcu_scale": 1.22,
    "note": "Seedance did not preserve greenscreen; STUDIO_OTS uses soft elliptical matte + optional dark-blue colorkey assist",
}, indent=2, ensure_ascii=False))

DUR = json.loads((ROOT/"clips"/"durations.json").read_text())
DUR.setdefault("bumper_in", 2.0)
DUR.setdefault("bumper_out", 2.0)
DUR.setdefault("end_card", 2.0)

TICKER = [
    "【本台快訊】研究發現：人類只要保持呼吸就能有效阻止窒息",
    "【氣象提醒】今日全國大部分地區白天有光，夜間普遍偏黑",
    "【財經觀察】專家指出：錢花光之後帳戶普遍會出現餘額不足現象",
    "【嚴正聲明】以上內容純屬胡扯 · 請勿當真",
]
TICKER_TEXT = "　　".join(TICKER) + "　　" + "　　".join(TICKER)

SHOT_META = {
  "open_01": dict(layout="STUDIO_OTS", lower="創刊特輯 · 本台「零真相、純扯淡」嚴正聲明", l1t="正經胡說報 · 創刊號", crop="MS"),
  "open_02": dict(layout="STUDIO_OTS", lower="違規播報真實新聞處罰條例：涉事編導一律扣雞腿", l1t="【最高處分】扣雞腿一次", crop="MCU"),
  "bumper_in": dict(layout="BUMPER", lower="", l1t="", l1_src=str(ROOT/"assets/trans/logo_out.mp4")),
  "body_a1": dict(layout="STUDIO_OTS", lower="本台核心綱領：開局一張圖 · 內容全靠編", l1t="虛構率：100% ｜ 公信力：0%", crop="MS"),
  "body_a2": dict(layout="FULL_L1", lower="數據來源：本台編導剛剛花了三秒鐘捏造的權威統計", l1t="《觀眾大腦皮層光滑度走勢圖》 · 智商休眠率 99.8%"),
  "body_b1": dict(layout="FULL_L1", lower="【今日瞎編快訊 01】「賴床」被正式列為人類一級本能防禦機制", l1t="信源：世界賴床研究總署（剛剛成立）"),
  "body_b2": dict(layout="FULL_L1", lower="專家警告：清晨抗拒感本質是免疫系統在阻止你去給老闆創造財富", l1t="著名虛構醫學家 · 麥克阿瑟分瑟｜強行早起＝嚴重自殘"),
  "body_c1": dict(layout="FULL_L1", lower="【今日瞎編快訊 02】地鐵車廂驚現殿堂級「信念感」表演現場", l1t="連續三年零失誤 · 面對三位大爺依然維持深度假寐"),
  "body_c2": dict(layout="FULL_L1", lower="頒獎詞：只要我不睜眼，道德就綁架不了我", l1t="榮獲：當代沉浸式戲劇表演藝術家 · 終身成就獎"),
  "bumper_out": dict(layout="BUMPER", lower="", l1t="", l1_src=str(ROOT/"assets/trans/logo_in.mp4")),
  "close_01": dict(layout="STUDIO_OTS", lower="免責聲明：本節目一切人物、數據及標點符號純屬虛構", l1t="如有雷同 · 說明這個世界終於徹底瘋了", crop="MS"),
  "end_card": dict(layout="BUMPER", lower="", l1t="", l1_src=str(L1/"end_card.mp4")),
}
ORDER = ["open_01","open_02","bumper_in","body_a1","body_a2","body_b1","body_b2","body_c1","body_c2","bumper_out","close_01","end_card"]

def font(sz, bold=True):
    try:
        return ImageFont.truetype(FONT_B if bold else FONT_R, sz, index=0)
    except Exception:
        return ImageFont.load_default()

def ff(*args):
    r = subprocess.run(["ffmpeg","-y",*args], capture_output=True, text=True)
    if r.returncode != 0:
        print("FFMPEG ERR", r.stderr[-2000:])
        raise RuntimeError(f"ffmpeg failed: {args[:6]}")
    return r

def make_matte_png(path, scale=1.0):
    """Soft elliptical matte favoring left-center person + desk."""
    m = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(m)
    # ellipse covering person+desk roughly center-left
    cx, cy = int(W*0.38), int(H*0.55)
    rx, ry = int(W*0.32*scale), int(H*0.55*scale)
    d.ellipse([cx-rx, cy-ry, cx+rx, cy+ry], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(radius=40))
    m.save(path)
    return path

MATTE = COMP / "actor_matte.png"
make_matte_png(MATTE, 1.0)
MATTE_MCU = COMP / "actor_matte_mcu.png"
make_matte_png(MATTE_MCU, 1.15)

def render_l3_png(lower, l1t, show_ticker=True, ticker_offset=0):
    img = Image.new("RGBA", (W, H), (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([40, 36, 320, 100], radius=8, fill=(180, 20, 30, 230))
    d.text((58, 48), "正經胡說報", font=font(32, True), fill=(255,255,255,255))
    if lower:
        d.rectangle([0, 860, W, 980], fill=(12, 24, 48, 230))
        d.rectangle([0, 860, 14, 980], fill=(220, 40, 40, 255))
        d.text((36, 890), lower[:48], font=font(32, True), fill=(240,245,255,255))
        if len(lower) > 48:
            d.text((36, 935), lower[48:96], font=font(28, False), fill=(200,210,230,255))
    if l1t:
        tw = min(W-80, 40 + len(l1t)*26)
        d.rounded_rectangle([40, 120, 40+tw, 172], radius=6, fill=(0,0,0,170))
        d.text((55, 130), l1t[:42], font=font(26, True), fill=(255,220,120,255))
    if show_ticker:
        d.rectangle([0, 1000, W, H], fill=(8, 12, 28, 245))
        d.rectangle([0, 1000, W, 1004], fill=(200, 40, 40, 255))
        x = int(W - (ticker_offset % (len(TICKER_TEXT)*22 + W)))
        d.text((x, 1020), TICKER_TEXT, font=font(24, False), fill=(220,230,245,255))
    return img

def make_l3_video(dur, lower, l1t, show_ticker, out_path):
    nf = max(1, int(round(dur * FPS)))
    td = Path(tempfile.mkdtemp(prefix="l3_"))
    # render fewer unique frames for speed: 1 per 0.25s then stretch? Better full for smooth ticker
    step = 1  # every frame
    for i in range(0, nf, step):
        off = i / FPS * 160
        im = render_l3_png(lower, l1t, show_ticker, off)
        im.save(td / f"f_{i:05d}.png")
    # if stepped, duplicate — we use every frame
    ff("-framerate", str(FPS), "-i", str(td/"f_%05d.png"),
       "-c:v","libx264","-pix_fmt","yuva420p" if False else "yuv420p","-crf","18",
       "-vf", "format=yuva420p" if False else "format=yuv420p",
       str(out_path))
    # Actually need alpha for overlay — use png sequence via overlay with colorkey black? 
    # Simpler: save as video with black=transparent via geq? Easiest: overlay PNG seq directly in compose.
    # Re-save as mov with alpha using png
    shutil.rmtree(td, ignore_errors=True)
    # regenerate as qtrle/png mov? For speed use premultiplied: black bg + screen? 
    # We'll re-approach: write l3 as PNG sequence dir and use -framerate in filter
    td2 = Path(str(out_path) + "_png")
    if td2.exists(): shutil.rmtree(td2)
    td2.mkdir()
    for i in range(nf):
        off = i / FPS * 160
        render_l3_png(lower, l1t, show_ticker, off).save(td2 / f"f_{i:05d}.png")
    # create a video WITH alpha using libvpx or qtrle
    ff("-framerate", str(FPS), "-i", str(td2/"f_%05d.png"),
       "-c:v","ffv1", "-pix_fmt","yuva420p", str(out_path).replace(".mp4",".mkv"))
    return Path(str(out_path).replace(".mp4",".mkv")), td2

def compose_shot(sid):
    meta = SHOT_META[sid]
    dur = float(DUR[sid])
    layout = meta["layout"]
    out = COMP / f"{sid}.mp4"
    print(f"compose {sid} layout={layout} dur={dur}", flush=True)

    if layout == "BUMPER":
        src = meta.get("l1_src") or str(L1/f"{sid}.mp4")
        # no L3
        has_a = subprocess.run(["ffprobe","-v","error","-select_streams","a","-show_entries","stream=codec_type","-of","csv=p=0",src], capture_output=True, text=True).stdout.strip()
        if has_a:
            ff("-i", src, "-t", f"{dur:.3f}",
               "-vf", "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1",
               "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-c:a","aac","-b:a","192k",
               "-t", f"{dur:.3f}", str(out))
        else:
            ff("-i", src, "-f","lavfi","-i","anullsrc=r=48000:cl=stereo",
               "-t", f"{dur:.3f}",
               "-vf", "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1",
               "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-c:a","aac","-b:a","192k","-shortest",
               str(out))
        return out

    # Build L3 png sequence
    nf = max(1, int(round(dur * FPS)))
    l3dir = COMP / f"{sid}_l3png"
    if l3dir.exists(): shutil.rmtree(l3dir)
    l3dir.mkdir()
    # speed: render every 2nd frame and use fps filter — for ticker smoothness every frame is better but heavy
    # Use every frame for ≤12s = ≤288 frames OK
    for i in range(nf):
        render_l3_png(meta["lower"], meta["l1t"], True, i/FPS*160).save(l3dir/f"f_{i:05d}.png")

    if layout == "FULL_L1":
        l1 = L1 / f"{sid}.mp4"
        wav = AUD / f"{sid}.wav"
        # loop L1 if shorter than dur
        ff("-stream_loop","-1","-i",str(l1),
           "-framerate",str(FPS),"-i",str(l3dir/"f_%05d.png"),
           "-i",str(wav),
           "-filter_complex",
           f"[0:v]scale=1920:1080,setsar=1,trim=duration={dur:.3f},setpts=PTS-STARTPTS[v0];"
           f"[1:v]format=rgba,trim=duration={dur:.3f},setpts=PTS-STARTPTS[v3];"
           f"[v0][v3]overlay=0:0:format=auto[vout];"
           f"[2:a]atrim=duration={dur:.3f},asetpts=PTS-STARTPTS,aresample=48000[aout]",
           "-map","[vout]","-map","[aout]",
           "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-c:a","aac","-b:a","192k",
           "-t", f"{dur:.3f}", str(out))
        return out

    if layout == "STUDIO_OTS":
        actor = TRIM / f"{sid}.mp4"
        l1 = L1 / f"{sid}.mp4"
        sx = int(SCREEN["x"]*W); sy=int(SCREEN["y"]*H)
        sw=int(SCREEN["w"]*W); sh=int(SCREEN["h"]*H)
        mcu = meta.get("crop")=="MCU"
        matte = MATTE_MCU if mcu else MATTE
        # scale: MCU 1.22x zoom on actor before matte
        if mcu:
            # zoom 1.22 crop chest-up then fit left
            actor_vf = (
                f"[1:v]scale=1920:1080,setsar=1,"
                f"scale=iw*1.22:ih*1.22,"
                f"crop=1920:1080:(in_w-1920)/2:0,"
                f"trim=duration={dur:.3f},setpts=PTS-STARTPTS[actv];"
            )
        else:
            actor_vf = (
                f"[1:v]scale=1920:1080,setsar=1,"
                f"trim=duration={dur:.3f},setpts=PTS-STARTPTS[actv];"
            )
        # Approach: L0 + L1 screen + actor full-frame with soft matte (so right side of actor video fades, revealing L1 screen)
        # Also try mild colorkey on dark teal to help edges
        fc = (
            f"[3:v]scale=1920:1080,format=gray,trim=duration={dur:.3f},setpts=PTS-STARTPTS[mask];"
            f"[2:v]scale={sw}:{sh},trim=duration={dur:.3f},setpts=PTS-STARTPTS[scr];"
            f"[0:v]scale=1920:1080,trim=duration={dur:.3f},setpts=PTS-STARTPTS[bg];"
            f"[bg][scr]overlay={sx}:{sy}:format=auto[b1];"
            f"{actor_vf}"
            f"[actv][mask]alphamerge[acta];"
            f"[b1][acta]overlay=0:0:format=auto[b2];"
            f"[4:v]format=rgba,trim=duration={dur:.3f},setpts=PTS-STARTPTS[ov];"
            f"[b2][ov]overlay=0:0:format=auto[vout];"
            f"[1:a]atrim=duration={dur:.3f},asetpts=PTS-STARTPTS,aresample=48000[aout]"
        )
        ff("-loop","1","-i",str(BG),
           "-i",str(actor),
           "-stream_loop","-1","-i",str(l1),
           "-loop","1","-i",str(matte),
           "-framerate",str(FPS),"-i",str(l3dir/"f_%05d.png"),
           "-filter_complex", fc,
           "-map","[vout]","-map","[aout]",
           "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-c:a","aac","-b:a","192k",
           "-t", f"{dur:.3f}", str(out))
        return out

    raise RuntimeError(layout)

def concat_all():
    # re-encode each to same timebase then concat
    lst = COMP / "concat.txt"
    lines = []
    for sid in ORDER:
        p = COMP / f"{sid}.mp4"
        # normalize
        norm = COMP / f"{sid}_norm.mp4"
        ff("-i", str(p),
           "-vf","scale=1920:1080,setsar=1,fps=24",
           "-c:v","libx264","-pix_fmt","yuv420p","-crf","18",
           "-c:a","aac","-b:a","192k","-ar","48000","-ac","2",
           str(norm))
        lines.append(f"file '{norm}'")
    lst.write_text("\n".join(lines))
    final = OUT / "EP001_v2_final.mp4"
    ff("-f","concat","-safe","0","-i",str(lst),
       "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-c:a","aac","-b:a","192k",
       str(final))
    return final

if __name__ == "__main__":
    import sys
    shots = [a for a in sys.argv[1:] if not a.startswith("-")] or ORDER
    for sid in shots:
        if sid not in SHOT_META: 
            print("skip unknown", sid); continue
        compose_shot(sid)
    if not shots or shots == ORDER or "--concat" in sys.argv:
        # concat if all present
        if all((COMP/f"{s}.mp4").exists() for s in ORDER):
            final = concat_all()
            print("FINAL", final)
        else:
            missing = [s for s in ORDER if not (COMP/f"{s}.mp4").exists()]
            print("MISSING for concat", missing)
