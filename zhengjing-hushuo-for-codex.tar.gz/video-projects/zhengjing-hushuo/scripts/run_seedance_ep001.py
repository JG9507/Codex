#!/usr/bin/env python3
"""Build Seedance prompts and submit EP001 shots — exact YAML Traditional Chinese."""
import json, subprocess, sys
from pathlib import Path

ROOT = Path("/workspace/video-projects/zhengjing-hushuo")
OUT = ROOT / "clips" / "seedance"
OUT.mkdir(parents=True, exist_ok=True)
JOBS = ROOT / "clips" / "seedance_jobs.json"

VOICE = {
  "anchor_main": "標準晚間新聞聯播女聲，字正腔圓，語速平穩，莊重嚴肅，零笑場",
  "vo_male": "渾厚紀錄片與晚間新聞男播音員聲線，嚴肅緊迫，字正腔圓",
}
IMG = {
  "anchor_main": str(ROOT / "refs/anchor_main_greenscreen_ms.png"),
  "vo_male": str(ROOT / "refs/vo_male_anchor_ref.png"),
}

SHOTS = [
  dict(id="open_01", role="anchor_main", dur=12,
       action="新聞女主播身穿深色西裝正襟危坐，面色凝重，雙手交疊在桌面，直視鏡頭嚴肅播報，零笑場",
       line="觀眾朋友們晚上好，歡迎收看正經胡說報。首先向大家發出最誠摯的警告：本台絕不播報半點真相。"),
  dict(id="open_02", role="anchor_main", dur=12,
       action="新聞女主播身穿深色西裝，表情嚴肅認真，眉頭微蹙，右手微微抬起做強調手勢後落回桌面，零笑場",
       line="如果您在收看時不幸學到了有用知識，請立即投訴，我們將對涉事編導予以嚴肅的扣雞腿處理。"),
  dict(id="body_a1", role="anchor_main", dur=10,
       action="新聞女主播正襟危坐，神態自信且莊重，直視鏡頭平穩播報，零笑場",
       line="作為一家毫無公信力的媒體，本台始終堅持開局一張圖、內容全靠編的指導方針。"),
  dict(id="body_a2", role="anchor_main", dur=12,
       action="新聞女主播端莊播報",
       line="據本台剛剛捏造的數據顯示，百分之九十九點八的觀眾收看後，大腦皮層光滑度提升了三個百分點。"),
  dict(id="body_b1", role="vo_male", dur=12,
       action="新聞男播音員嚴肅播報",
       line="下面插播兩條簡訊。世界賴床研究總署今日凌晨突然沒有宣布，賴床被正式列為人類本能防禦機制。"),
  dict(id="body_b2", role="vo_male", dur=7,
       action="新聞男播音員嚴肅播報",
       line="抗拒早起是在阻止你給老闆賺錢，強行起床屬於自殘。"),
  dict(id="body_c1", role="vo_male", dur=7,
       action="新聞男播音員嚴肅播報",
       line="市民張先生連續三年在地鐵閉眼裝睡、成功躲避讓座。"),
  dict(id="body_c2", role="vo_male", dur=7,
       action="新聞男播音員嚴肅播報",
       line="今日被正式授予當代沉浸式戲劇表演藝術家榮譽稱號。"),
  dict(id="close_01", role="anchor_main", dur=11,
       action="新聞女主播雙手交疊放在桌上，露出極其標準、官方、毫無靈魂的職業微笑，微微點頭致意，保持端莊定格",
       line="以上就是本期胡說八道的全部內容。這裡是正經胡說報，我們下期繼續扯淡，再見。"),
]

def build_prompt(s):
    vs = VOICE[s["role"]]
    return (
        f'固定機位（Locked camera），純色背景無光影變化。{s["action"]}。'
        f'安靜演播室錄音棚音質，無背景音樂，無環境雜音。'
        f'畫面人物用{vs}清晰播報：“{s["line"]}” 說完後保持端莊表情靜止。'
    )

def submit(s):
    out = OUT / f'{s["id"]}.mp4'
    if out.exists() and out.stat().st_size > 100_000:
        print(f'SKIP exists {s["id"]} ({out.stat().st_size} bytes)', flush=True)
        return {"id": s["id"], "status": "exists", "path": str(out)}
    prompt = build_prompt(s)
    cmd = [
        "comfy", "generate", "seedance",
        "--prompt", prompt,
        "--image", IMG[s["role"]],
        "--model", "seedance-1-5-pro-251215",
        "--ratio", "16:9",
        "--resolution", "1080p",
        "--duration", str(s["dur"]),
        "--generate_audio", "true",
        "--camerafixed", "true",
        "--watermark", "false",
        "--download", str(out),
        "--yes",
        "--timeout", "900",
        "--json",
    ]
    print(f'=== SUBMIT {s["id"]} dur={s["dur"]} role={s["role"]} ===', flush=True)
    r = subprocess.run(cmd, capture_output=True, text=True)
    print("STDOUT_TAIL:", (r.stdout or "")[-2500:], flush=True)
    print("STDERR_TAIL:", (r.stderr or "")[-1500:], flush=True)
    print("RC:", r.returncode, "exists:", out.exists(), "size:", out.stat().st_size if out.exists() else 0, flush=True)
    return {"id": s["id"], "rc": r.returncode, "stdout": (r.stdout or "")[-4000:], "stderr": (r.stderr or "")[-2000:], "path": str(out), "exists": out.exists()}

if __name__ == "__main__":
    if "--dry" in sys.argv:
        for s in SHOTS:
            print("====", s["id"], "===="); print(build_prompt(s)); print()
        sys.exit(0)
    wanted = [a for a in sys.argv[1:] if not a.startswith("-")]
    results = []
    for s in SHOTS:
        if wanted and s["id"] not in wanted:
            continue
        results.append(submit(s))
        JOBS.write_text(json.dumps(results, ensure_ascii=False, indent=2))
    print("DONE", json.dumps([{k:r.get(k) for k in ('id','rc','path','status','exists') if k in r} for r in results], ensure_ascii=False))
