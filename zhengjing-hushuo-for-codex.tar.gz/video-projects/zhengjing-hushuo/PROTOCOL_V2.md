# 《正经胡说报》Gemini ⇄ Grok 终极交接协议 (V2.0 生产锁定版)

> 落盘路径：`/workspace/video-projects/zhengjing-hushuo/PROTOCOL_V2.md`  
> Grok 在执行「演播室分层新闻短片」合成、解析 Gemini YAML 时**必须严格按本协议**。

---

## 1. 核心铁律与算术边界（Gemini 编写约束）

1. **字数与整数秒公式**：
   - 单镜 `char_count`（纯汉字+标点计数）硬上限：**≤ 44 字**。
   - Seedance `dur_sec` 必须为 **整数（Integer 3–12）**，严禁出现小数。
   - 换算公式：`dur_sec = clamp(ceil(char_count / 4.0) + 1, 3, 12)`。
2. **Flow 镜头时长上限（防拆段/防卡顿）**：
   - 凡是指定 `L1_media.tool: flow` 的镜头，Gemini 必须将该镜 `char_count` 控制在 **≤ 24 字**（对应 `dur_sec` 为 **6 或 7 秒**），确保单段 Flow（6–8s）100% 覆盖口播，禁止出现让 Grok 拆段或定格末帧的情况。
3. **防跳剪与数码变焦（Post-Crop 机制）**：
   - Seedance 生成永远使用同一张中景绿幕首帧（`MS`），禁止要求 Seedance 运镜或切景别。
   - 同角色连续两镜说话时，若不切 `FULL_L1`，第二镜将 `L2_actor.post_crop` 设为 `MCU`（由 Grok 在 FFmpeg 合成时将抠像后的 L2 图层放大 `1.22x` 并裁切胸部以上），实现零跳帧的机位切换。
4. **文本净化**：
   - `seedance_line` 内所有阿拉伯数字、百分比、英文缩写必须写成中文读法（如 `百分之九十九点八`），严禁包含双引号 `"` 或括号情绪提示词。

---

## 2. 图层合成与 Layout 显隐矩阵（Grok FFmpeg 规范）

成片画幅：`1920x1080 (16:9)`。Z-Order 从下至上：`L0_bg → L1_media → L2_actor → L3_overlay`。

| `layout` 枚举 | `L0_bg` (空厅底图) | `L1_media` (画面/图表) | `L2_actor` (绿幕人物) | `L3_overlay` (角标/滚动条/下三分) |
| :--- | :--- | :--- | :--- | :--- |
| `STUDIO_OTS` | 显示 (`1920x1080`) | 显示（裁切/缩放至右侧屏框几何区） | 显示（左侧偏中，抠像叠加） | **全部显示**（含右屏主副标题/下三分/Ticker） |
| `STUDIO_SOLO` | 显示 (`1920x1080`) | 隐藏 (`none`) | 显示（居中，抠像叠加） | **显示**（角标 + 下三分 + Ticker） |
| `FULL_L1` | 隐藏 | **全屏铺满 (`1920x1080`)** | 仅抽音轨 (`audio_only`)，画面隐藏 | **显示**（角标 + 下三分 + Ticker + `l1_overlay_text`） |
| `SPLIT_2UP` | 显示 (`1920x1080`) | 隐藏 (`none`) | 左右双人分屏框（主播左 + 嘉宾右） | **显示**（角标 + 下三分 + Ticker） |
| `BUMPER` | 隐藏 | 全屏播放转场视频或片尾字卡 | 隐藏 (`none`) | **全部隐藏**（严禁在转场 Logo 上叠滚动条） |

补充（与上表一致）：

- `STUDIO_OTS`：L0 + 右侧屏框 L1 + 左侧偏中抠像 L2 + 全部 L3。
- `STUDIO_SOLO`：L0 + 隐藏 L1 + 居中抠像 L2 + L3。
- `FULL_L1`：隐藏 L0；L1 全屏；L2 只抽音；L3 保留。
- `SPLIT_2UP`：L0 + 左右双人 L2 + L3。
- `BUMPER`：全屏转场／片尾字卡；**强制隐藏全部 L3**（严禁在大 Logo／黑屏片尾上叠滚动条与角标）。

---

## 3. Grok 工具调用硬规范

### 3.1 Seedance 1.5 Pro 组装模板与尾音修剪

- **固定 CLI 参数**：`--model seedance-1-5-pro-251215 --ratio 16:9 --resolution 1080p --generate_audio true`（`duration` = YAML 整数 `dur_sec`）。
- **全角色首帧必传（锁声铁律）**：
  - `anchor_main` → `--image /workspace/video-projects/zhengjing-hushuo/refs/anchor_main_greenscreen_ms.png`
  - `vo_male`（含 `mode: audio_only`）→ `--image /workspace/video-projects/zhengjing-hushuo/refs/vo_male_anchor_ref.png`
  - **严禁**省略 `--image` 跑 T2V。
- **`--prompt` 强制拼接公式**：
  > `固定机位（Locked camera），纯色背景无光影变化。<L2_actor.action_prompt>。安静演播室录音棚音质，无背景音乐，无环境杂音。画面人物用<roles[role_id].voice_style>清晰播报：“<seedance_line>” 说完后保持端庄表情静止。`
- **FFmpeg 尾音修剪（必做）**：检测人声结束点，**仅保留句尾 0.25s 自然气口**，裁掉后续静音发呆帧；以**裁剪后实际有效时长**驱动该镜 L0/L1/L3 合成时长。

### 3.2 防跳剪数码变焦（`post_crop`）

- Seedance 永远只生成 `MS`。
- 当 `L2_actor.post_crop: "MCU"` 时，抠像合成阶段将 L2 放大 **1.22x**（以胸部以上为中心裁切），再与上一镜 `MS` 硬切。

### 3.3 Flow 与 Code 渲染

- `tool: flow`：Grok 直接读取 YAML 英文 `visual_prompt` 提交 Google Flow（16:9），无需扩写中文。
- `tool: code`：Gemini 在 `L1_media.code_spec` 提供结构化描述；Grok 用 Python (Matplotlib/Pillow) 或 HTML5 Canvas 渲染 1080p 动态段。

---

## 4. 标准资产注册表

工程根：`/workspace/video-projects/zhengjing-hushuo/`

| 资产 ID | 绝对路径 | 状态 |
| :--- | :--- | :--- |
| `anchor_main_gs` | `/workspace/video-projects/zhengjing-hushuo/refs/anchor_main_greenscreen_ms.png` | **已就绪**（Step 0） |
| `vo_male_ref` | `/workspace/video-projects/zhengjing-hushuo/refs/vo_male_anchor_ref.png` | **已就绪**（Step 0） |
| `studio_empty_bg` | `/workspace/video-projects/zhengjing-hushuo/assets/bg/studio_empty_16x9.png` | **已就绪**（Step 0） |
| `trans_logo_out` | `/workspace/video-projects/zhengjing-hushuo/assets/trans/logo_out.mp4` | **已就绪**（2.0s） |
| `trans_logo_in` | `/workspace/video-projects/zhengjing-hushuo/assets/trans/logo_in.mp4` | **已就绪**（2.0s） |
